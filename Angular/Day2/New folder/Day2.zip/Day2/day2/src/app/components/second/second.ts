import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-second',
  imports: [],
  templateUrl: './second.html',
  styleUrl: './second.css',
  // encapsulation: ViewEncapsulation.None,
})

// ng host element(component) -> selfstudy in lab
export class Second {}
